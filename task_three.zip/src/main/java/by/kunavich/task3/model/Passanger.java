package by.kunavich.task3.model;

public class Passanger {
    private String name;

    public Passanger(String nName)
    {
        name =nName;
    }

    public String getName() {
        return name;
    }
}
